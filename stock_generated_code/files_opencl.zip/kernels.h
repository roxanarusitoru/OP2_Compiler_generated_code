#include "real.h"

void
save_soln(REAL *q, REAL *qold);

void 
res_calc(REAL *x1,  REAL *x2,  REAL *q1,  REAL *q2,
                     REAL *adt1,REAL *adt2,REAL *res1,REAL *res2);

void 
bres_calc(REAL *x1,  REAL *x2,  REAL *q1,
                      REAL *adt1,REAL *res1,int *bound);

void
adt_calc(REAL *x1,REAL *x2,REAL *x3,REAL *x4,REAL *q,REAL *adt);

void
update(REAL *qold, REAL *q, REAL *res, REAL *adt, REAL *rms);

void 
fusedOne(REAL *q, REAL *qold, REAL *x1,REAL *x2,REAL *x3,REAL *x4,REAL *adt);

void
fusedTwo(REAL *qold, REAL *q, REAL *res, REAL *adt, REAL *rms, REAL *x1,REAL *x2,REAL *x3,REAL *x4);

